package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.accenture.adf.businesstier.entity.Event;
import com.accenture.adf.businesstier.entity.Visitor;
import com.accenture.adf.businesstier.service.EventServiceImpl;
import com.accenture.adf.helper.FERSDataConnection;

/**
 * Junit test case to test class EventServiceImpl
 *
 */

//DONE//
public class TestEventServiceImpl {

	private List<Event> eventList,i;	
	private Visitor visitor;
	private EventServiceImpl eventServiceImpl;
	int count=0;

	/**
	 * Set up the objects required before execution of every method
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {		
		eventServiceImpl = new EventServiceImpl();
		visitor = new Visitor();
	}

	/**
	 * Deallocates the objects after execution of every method
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null  
		 */
		eventServiceImpl=null;
		visitor=null;
		eventList=null;
	}

	/**
	 * Test case to test the method getAllEvents
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@Test
	public void testGetAllEvents() throws ClassNotFoundException, SQLException {
		/**
		 * @TODO: Call getAllEvents method and assert it for the size of returned array
		 */		
		i=eventServiceImpl.getAllEvents();
		Connection conn=FERSDataConnection.createConnection();
		PreparedStatement statement=conn.prepareStatement("select eventid from event");
		ResultSet rs=statement.executeQuery();
		while(rs.next())
		{
			++count;
		}
		assertEquals(count,i.size());
		
	}

	/**
	 * Test case to test the method checkEventsofVisitor
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@Test
	public void testCheckEventsofVisitor() throws ClassNotFoundException, SQLException {
		boolean j=false;
		/**
		 * @TODO: Call checkEventsofVisitor and assert the returned type of this method
		 * for appropriate return type
		 */	
		visitor.setVisitorId(1001);
		j=eventServiceImpl.checkEventsofVisitor(visitor, 1003);
		System.out.println(j);
		assertEquals(true,j);	
	}

	/**
	 * Test case to test the method updateEventDeletions
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@Test
	public void testUpdateEventDeletions() throws ClassNotFoundException, SQLException {
		/**
		 * @TODO: Call updateEventDeletions and assert the return type of this method
		 */		
		int i=0,j=0;
		int temp=0;
		Connection conn=FERSDataConnection.createConnection();
		PreparedStatement statement=conn.prepareStatement("SELECT SEATSAVAILABLE FROM EVENT WHERE EVENTID = ?");
		statement.setInt(1,1001);
		ResultSet rs=statement.executeQuery();
		while(rs.next())
		{
			i=rs.getInt(1);
		}
		
		eventServiceImpl.updateEventDeletions(1001);
		
		PreparedStatement statement2=conn.prepareStatement("SELECT SEATSAVAILABLE FROM EVENT WHERE EVENTID = ?");
		statement2.setInt(1,1001);
		ResultSet resultSet2=statement2.executeQuery();
		while(resultSet2.next())
		{
			j=resultSet2.getInt(1);
		}
		assertEquals(i,j-1);
	}

}

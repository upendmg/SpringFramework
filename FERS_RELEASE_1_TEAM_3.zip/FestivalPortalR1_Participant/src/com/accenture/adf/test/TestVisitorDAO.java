package com.accenture.adf.test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.accenture.adf.businesstier.dao.VisitorDAO;
import com.accenture.adf.businesstier.entity.Event;
import com.accenture.adf.businesstier.entity.Visitor;
import com.accenture.adf.helper.FERSDataConnection;

/**
 * JUnit test case for VisitorDAO class for testing all repository methods to
 * call database sub-routines
 * 
 */
public class TestVisitorDAO {
	
	private Visitor visitor;
	private VisitorDAO visitorDAO;
	private ArrayList<Event> registeredEvents, rs1;
	private static ResultSet resultSet,resultSet1,resultSet2= null;

	/**
	 * Setting up initial objects 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		visitor = new Visitor();
		visitorDAO = new VisitorDAO();
		registeredEvents = new ArrayList<Event>();
	}

	/**
	 * Deallocating objects after execution of every method
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null  
		 */
		visitor=null;
		visitorDAO=null;
		registeredEvents=null;	
	}

	/**
	 * Test case for method insertData
	 * @throws Exception 
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@Test
	public void testInsertData() throws ClassNotFoundException, SQLException, Exception {
		/**
		 * @TODO: Create visitor object by setting appropriate values
		 * Call insertData method by passing this visitor object
		 * Search this new visitor object by calling searchUser method
		 * Assert the values of username
		 */		
		//Visitor vNew=new Visitor();
		visitor.setVisitorId(1009);
		visitor.setUserName("akshay");
		visitor.setPassword("pass");
		visitor.setFirstName("akshay");
		visitor.setLastName("sripad");
		visitor.setEmail("aks@g.com");
		visitor.setPhoneNumber("98741");

		visitorDAO.insertData(visitor);
		Visitor vNew=visitorDAO.searchUser("akshay","pass");
		assertEquals(visitor.getVisitorId(),vNew.getVisitorId());
		
		
	}	

	/**
	 * Test case for method searchUser
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@Test
	public void testSearchUser() throws ClassNotFoundException, SQLException {
		/**
		 * @TODO: Call searchUser method for valid values of username
		 * and password and assert the value of username for the returned type of method
		 */		
		Visitor vNew=new Visitor();
		vNew=visitorDAO.searchUser("bsmith","password");
		assertEquals("bsmith",vNew.getUserName());
		
		
	}

	/**
	 * Test case for method registerVisitorToEvent
	 * @throws Exception 
	 */
	@Test
	public void testRegisterVisitorToEvent() throws Exception {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Pass this visitor object and valid eventid to registerVisitorToEvent method
		 * and assert the value
		 */		
		int i=0,j=0;
		Connection conn=FERSDataConnection.createConnection(); 
		visitor=visitorDAO.searchUser("anurag","pass");
		PreparedStatement stmt1=conn.prepareStatement("Select * from eventsignup");
		ResultSet rs=stmt1.executeQuery();
		while(rs.next())
		{
			++i;
		}
		visitorDAO.registerVisitorToEvent(visitor,1003);
		rs=stmt1.executeQuery();
		while(rs.next())
		{
			++j;
		}
		assertEquals(i,j-1);
		
		
		
		
	}	

	/**
	 * Test case for method registeredEvents
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@Test
	public void testRegisteredEvents() throws ClassNotFoundException, SQLException {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Pass this visitor object and valid eventid to registeredEvents method
		 * and assert the value
		 */	
		Connection conn=FERSDataConnection.createConnection(); 
		visitor=visitorDAO.searchUser("anurag", "pass");
		System.out.println(visitor.getVisitorId());
		PreparedStatement smt=conn.prepareStatement("select eventid from eventsignup where visitorid=?");
		smt.setInt(1,visitor.getVisitorId());
		ResultSet rs=smt.executeQuery();
		int i=0;
		while(rs.next())
		{
			++i;
		}
		
		registeredEvents=visitorDAO.registeredEvents(visitor);
		
		
		for(Event ref:registeredEvents)
		{
			System.out.println(ref.getEventid());
			
		}
		assertEquals(i,registeredEvents.size());
		
	}

	/**
	 * Test case for method updateVisitor
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@Test
	public void testUpdateVisitorDetails() throws ClassNotFoundException, SQLException {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Update the value in this visitor object
		 * Pass this visitor object to updateVisitor method
		 * and assert the value of changed value
		 */		
		visitor=visitorDAO.searchUser("adw", "passwordC");
		System.out.println("ID: "+visitor.getVisitorId());
		visitor.setFirstName("Adwait");
		visitor.setLastName("Koti");
		visitor.setUserName("anuuuu");
		visitor.setPassword("passwordC");
		visitor.setEmail("new@gmail.com");
		visitor.setPhoneNumber("9899990");
		visitor.setAddress("Hubballi");
		int status=visitorDAO.updateVisitor(visitor);
		assertEquals(true,status>=1);	
	}

	/**
	 * Test case for method registeredEvents
	 * @throws Exception 
	 */
	@Test
	public void testUnregisterEvent() throws Exception {
		/**
		 * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
		 * Pass this visitor object and valid eventid to unregisterEvent method
		 * and assert the value
		 */		
		int i=0,j=0,eventId=0;
		Connection conn=FERSDataConnection.createConnection(); 
		visitor=visitorDAO.searchUser("rkreiger", "password");
		System.out.println(visitor.getVisitorId());
		
		PreparedStatement smt1=conn.prepareStatement("select eventid from eventsignup where visitorid=?");
		smt1.setInt(1, visitor.getVisitorId());
		resultSet=smt1.executeQuery();
		while(resultSet.next())
		{
		   eventId=resultSet.getInt(1);	
		}
		
		System.out.println(resultSet);
		PreparedStatement smt2=conn.prepareStatement("select signupid from eventsignup");
		resultSet1 = smt2.executeQuery();
		while(resultSet1.next())
		{
			++i;
			System.out.println("counting  "+i);
		}
		visitorDAO.unregisterEvent(visitor,eventId);
		
		PreparedStatement smt3=conn.prepareStatement("select signupid from eventsignup");
		resultSet2=smt3.executeQuery();
		while(resultSet2.next())
		{
			++j;
			System.out.println("counting2"+j);
		}
		assertEquals(i,j+1);
		/*PreparedStatement smt=conn.prepareStatement("DELETE FROM EVENTSIGNUP WHERE EVENTID = ? AND VISITORID = ?");
		smt.setInt(1, resultSet.getInt(1));
		smt.setInt(2,visitor.getVisitorId());*/
		 //rs1= smt.executeQuery();
		// System.out.println(rs1);
		 
		
		
		//assertEquals(true,
		
	}		
}

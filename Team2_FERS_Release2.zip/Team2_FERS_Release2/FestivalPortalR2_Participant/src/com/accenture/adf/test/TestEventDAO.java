	package com.accenture.adf.test;
	
	 
	import static org.junit.Assert.assertEquals;
	 
	import static org.junit.Assert.assertTrue;
	 
	import static org.junit.Assert.fail;
	
	 
	import java.sql.Connection;
	 
	import java.sql.PreparedStatement;
	 
	import java.sql.ResultSet;
	 
	import java.sql.SQLException;
	 
	import java.util.ArrayList;
	 
	import java.util.List;
	
	 
	import junit.framework.Assert;
	
	 
	import org.junit.After;
	 
	import org.junit.AfterClass;
	 
	import org.junit.Before;
	 
	import org.junit.BeforeClass;
	 
	import org.junit.Test;
	
	 
	import com.accenture.adf.businesstier.dao.EventDAO;
	 
	import com.accenture.adf.businesstier.entity.Event;
	 
	import com.accenture.adf.businesstier.entity.EventCoordinator;
	 
	import com.accenture.adf.businesstier.entity.Visitor;
	 
	import com.accenture.adf.exceptions.FERSGenericException;
	 
	import com.accenture.adf.helper.FERSDataConnection;
	 
	import com.sun.org.apache.bcel.internal.generic.GETSTATIC;
	
	 
	/**
	
	* Junit test class for EventDAO class
	
	* 
	
	*/
	 
	public class TestEventDAO {
	
	 
	private static Connection connection = null;
	 
	private static PreparedStatement statement = null, statement1=null;
	 
	private static ResultSet resultSet = null,resultSet1=null;
	 
	private ArrayList<Object[]> showAllEvents;
	 
	private EventDAO dao;
	
	 
	/**
	
	* Sets up database connection before other methods are executed in this
	
	* class
	
	* 
	 
	* @throws Exception
	
	*/
	 
	@BeforeClass
	 
	public static void setUpDatabaseConnection() throws Exception {
	 
	connection = FERSDataConnection.createConnection();
	
	}
	
	 
	/**
	
	* Closes the database connection after all the methods are executed
	
	* 
	 
	* @throws Exception
	
	*/
	 
	@AfterClass
	 
	public static void tearDownDatabaseConnection() throws Exception {
	 
	connection.close();
	 

	 
	}
	
	 
	/**
	
	* Sets up the objects required in other methods
	
	* 
	 
	* @throws Exception
	
	*/
	 
	@Before
	 
	public void setUp() throws Exception {
	 
	showAllEvents = new ArrayList<Object[]>();
	 
	dao = new EventDAO();
	
	}
	
	 
	/**
	
	* Deallocate the resources after execution of method
	
	* 
	 
	* @throws Exception
	
	*/
	 
	@After
	 
	public void tearDown() throws Exception {
	 
	/**
	 
	* @TODO: Release all the objects here by assigning them null 
	
	*/
	 
	dao=null;
	 
	showAllEvents=null;
	
	}
	
	 
	/**
	
	* Positive test case to test the method showAllEvents
	 
	* @throws SQLException 
	 
	* @throws ClassNotFoundException 
	
	*/
	 
	@Test
	 
	public void testShowAllEvents_Positive() throws ClassNotFoundException, SQLException {
	 
	/**
	 
	* @TODO: Call showAllEvents method and assert it for
	
	* size of returned type list
	 
	*/ 
	 
	showAllEvents=dao.showAllEvents();
	 
	assertEquals(8,showAllEvents.size());
	
	
	}
	
	 
	/**
	
	* Junit test case to test positive case for updateEventDeletions
	 
	* @throws Exception 
	 
	* @throws SQLException 
	 
	* @throws ClassNotFoundException 
	
	*/
	 
	@Test
	 
	public void testUpdateEventDeletions_Positive() throws ClassNotFoundException, SQLException, Exception {
	 
	
	 
	int i=0,j=0;
	statement=connection.prepareStatement("select seatsavailable from eventsession where eventid=?");
	statement.setInt(1,1001);
	resultSet=statement.executeQuery();
	
	while(resultSet.next())
	{
	i=resultSet.getInt(1);
	}
	
	 
	dao.updateEventDeletions(1001,10001);
	statement1=connection.prepareStatement("select seatsavailable from eventsession where eventid=?");
	statement1.setInt(1,1001);
	resultSet1=statement1.executeQuery();
	while(resultSet1.next())
	{
	j=resultSet1.getInt(1);
	}
	assertEquals(i+1,j);
	
	}
	
	 
	/**
	
	* Negative test case for method updateEventDeletions
	 
	* @throws Exception 
	 
	* @throws SQLException 
	 
	* @throws ClassNotFoundException 
	
	*/
	 
	@Test
	 
	public void testUpdateEventDeletions_Negative() throws ClassNotFoundException, SQLException, Exception {
	 
	int i=0,j=0; 
	statement=connection.prepareStatement("select seatsavailable from eventsession where eventid=?");
	statement.setInt(1,1001);
	resultSet=statement.executeQuery();
	 
	while(resultSet.next())
	{
	i=resultSet.getInt(1);
	}
	 
	dao.updateEventDeletions(1001,100213);
	statement1=connection.prepareStatement("select seatsavailable from eventsession where eventid=?");
	statement1.setInt(1,1001);
	resultSet1=statement1.executeQuery();
	 
	while(resultSet1.next())
	{
	j=resultSet1.getInt(1);
	}
	assertEquals(i+1,j);
	
	}
	
	
	
	 
	/**
	
	* Positive test case for method updateEventNominations
	 
	* @throws Exception 
	 
	* @throws ClassNotFoundException 
	
	*/
	 
	@Test
	 
	public void testUpdateEventNominations_Positive() throws ClassNotFoundException, Exception {
	
	int i=0,j=0; 
	statement=connection.prepareStatement("SELECT SEATSAVAILABLE FROM EVENTSESSION WHERE EVENTID = ?");
	statement.setInt(1,1002);
	resultSet=statement.executeQuery();
	 
	while(resultSet.next())
	{
	i=resultSet.getInt(1);
	}
	
	dao.updateEventNominations(1002, 10002); 
	statement1=connection.prepareStatement("SELECT SEATSAVAILABLE FROM EVENTSESSION WHERE EVENTID = ?");
	statement1.setInt(1,1002);
	 
	resultSet1=statement1.executeQuery();
	 
	while(resultSet1.next())
	{
	j=resultSet1.getInt(1);
	}
	assertEquals(i,j+1);
	
	}
	
	
	 
	/**
	
	* Negative test case for method updateEventNominations
	 
	* @throws Exception 
	 
	* @throws ClassNotFoundException 
	
	*/
	 
	@Test
	 
	public void testUpdateEventNominations_Negative() throws ClassNotFoundException, FERSGenericException,SQLException ,Exception{
	 
	 
	 
	int i=0,j=0; 
	statement=connection.prepareStatement("SELECT SEATSAVAILABLE FROM EVENTSESSION WHERE EVENTID = ?");
	statement.setInt(1,9999);
	resultSet=statement.executeQuery();
	 
	while(resultSet.next())
	{
	i=resultSet.getInt(1);
	}
	 
	dao.updateEventNominations(9999, 10002);
	statement1=connection.prepareStatement("SELECT SEATSAVAILABLE FROM EVENTSESSION WHERE EVENTID = ?");
	statement1.setInt(1,9999);
	 
	resultSet1=statement1.executeQuery();
	 
	while(resultSet1.next())
	{
	j=resultSet1.getInt(1);
	}
	
	assertEquals(i,j+1);
	
	}
	
	 
	/**
	
	* Positive test case for method checkEventsofVisitor
	 
	* @throws SQLException 
	 
	* @throws ClassNotFoundException 
	
	*/
	 
	@Test
	 
	public void testCheckEventsOfVisitor_Positive() throws ClassNotFoundException, SQLException {
	 
	
	Visitor visitor=new Visitor();
	visitor.setVisitorId(1001);
	dao.checkEventsofVisitor(visitor, 1001,10001);
	 
	assertEquals(true,dao.checkEventsofVisitor(visitor, 1001,10001));
	
	}
	
	 
	/**
	
	* Junit test case for getEventCoordinator
	 
	* @throws SQLException 
	 
	* @throws ClassNotFoundException 
	
	*/
	 
	@Test
	 
	public void testGetEventCoordinator() throws FERSGenericException{
	 
	 
	try {
	 
	List<EventCoordinator> eventCoordinatorList = dao.getEventCoordinator();
	 Assert.assertEquals(eventCoordinatorList.size() > 0, true);
	}
	catch (ClassNotFoundException e) { 
	fail("CNF Exception"); 
	} 
	catch (SQLException e) {
	fail(" SQL Exception"); 
	}
	
	}
	
	 
	/**
	
	* Junit test case for getEvent
	
	*/
	 
	@Test
	 
	public void testGetEvent(){
	 
	try { 
	Event event = dao.getEvent(1001, 10001);
	Assert.assertEquals(event.getEventid(), 1001);
	
	}
	catch (ClassNotFoundException e) {
	fail("CNF Exception"); 
	}
	
	catch (SQLException e) {
	fail("SQL Exception"); 
	}
	
	} 
	
	 
	/**
	
	* Junit test case for updateEvent
	
	*/
	 
	@Test
	 
	public void testInsertEvent() throws FERSGenericException{
	 
		try{
	
			Event insertEvent = new Event(); 
	
			insertEvent.setEventtype("eventtype");
			insertEvent.setName("eventname");
			insertEvent.setDescription("eventdesc");
			insertEvent.setPlace("eventplace");
			insertEvent.setDuration("0900-0600");
			insertEvent.setSeatsavailable("88"); 
			insertEvent.setEventCoordinatorId(101);
			int status = dao.insertEvent(insertEvent); 
	
			Assert.assertEquals(status == 1, true);
	
			} 
		 catch (ClassNotFoundException e) {
			fail("CNF Exception"); 
			} 
			catch (SQLException e) {
			fail("SQL Exception"); 
	
			} 
		
	
	}
	
	 
	/**
	
	* Junit test case for updateEvent
	
	*/
	 
	@Test
	 
	public void testUpdateEvent(){
	 
		try { 



			ArrayList<Object[]> eventObjectList = dao.showAllEvents("Rose Parade"); 

			Event updateEvent = new Event();

			for(Object[] eveObject: eventObjectList)
			{
			updateEvent.setEventid((Integer) eveObject[0]);
			updateEvent.setSessionId((Integer) eveObject[7]); 
			}

			updateEvent.setEventtype("eventtype");
			updateEvent.setName("eventname");
			updateEvent.setDescription("eventdesc");
			updateEvent.setPlace("eventplace");
			updateEvent.setDuration("1200-1300");
			updateEvent.setSeatsavailable("99"); 



			int status = dao.updateEvent(updateEvent); 



			Assert.assertEquals(status == 1, true);

			} catch (ClassNotFoundException e) {

			fail("CNF Exception"); 

			} catch (SQLException e) {

			fail("SQL Exception"); 

			} 

			}
	
	
	
	 
	/**
	
	* Junit test case for deleteEvent
	
	*/
	 
	@Test
	 
	public void testDeleteEvent(){
		try { 

			ArrayList<Object[]> eventObjectList = dao.showAllEvents(""); 
			Event deleteEvent = new Event();

			for(Object[] eveObject: eventObjectList){
			deleteEvent.setEventid((Integer) eveObject[0]);
			deleteEvent.setSessionId((Integer) eveObject[7]); 

			} 



			int status = dao.deleteEvent(deleteEvent.getEventid(), deleteEvent.getSessionId()); 
			Assert.assertEquals(status == 1, true);

			} catch (ClassNotFoundException e) {

			fail("CNF Exception"); 

			} catch (SQLException e) {

			fail("SQL Exception"); 

			} catch(FERSGenericException e){

			fail("FERSGenericException");

			}
	
	}
	
	}
	 
	

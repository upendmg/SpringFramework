package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
 import static org.junit.Assert.assertTrue;
 import static org.junit.Assert.fail;

import java.sql.Connection;
 import java.sql.PreparedStatement;
 import java.sql.ResultSet;
 import java.sql.SQLException;
 import java.util.ArrayList;
 import java.util.Arrays;

import org.junit.After;
 import org.junit.Before;
 import org.junit.Test;

import com.accenture.adf.businesstier.dao.VisitorDAO;
 import com.accenture.adf.businesstier.entity.Event;
 import com.accenture.adf.businesstier.entity.Visitor;
 import com.accenture.adf.helper.FERSDataConnection;

/**
  * JUnit test case for VisitorDAO class for testing all repository methods to
  * call database sub-routines
  * 
  */
 public class TestVisitorDAO {

 private Visitor visitor;
  private VisitorDAO visitorDAO;
  private ArrayList<Object[]> registeredEvents;

 /**
   * Setting up initial objects
   * 
   * @throws Exception
   */
  @Before
  public void setUp() throws Exception {
   visitor = new Visitor();
   visitorDAO = new VisitorDAO();
   registeredEvents = new ArrayList<Object[]>();
  }

 /**
   * Deallocating objects after execution of every method
   * @throws Exception
   */
  @After
  public void tearDown() throws Exception {
   /**
    * @TODO: Release all the objects here by assigning them null  
    */
   visitor=null;
   visitorDAO=null;
   registeredEvents=null;
  }

 /**
   * Test case for method insertData
   * @throws Exception 
   * @throws SQLException 
   * @throws ClassNotFoundException 
   */
  @Test
  public void testInsertData() throws ClassNotFoundException, SQLException, Exception {
   /**
    * @TODO: Create visitor object by setting appropriate values
    * Call insertData method by passing this visitor object
    * Search this new visitor object by calling searchUser method
    * Assert the values of username
    */  
   visitor.setVisitorId(1010);
   visitor.setUserName("ramon");
   visitor.setPassword("password");
   visitor.setFirstName("Ronit");
   visitor.setLastName("Mohanty");
   visitor.setPhoneNumber("1233");
   visitor.setEmail("a@b.com");
   visitor.setAddress(null);
   
   visitorDAO.insertData(visitor);
   
   Visitor v1=new Visitor();
   
   v1=visitorDAO.searchUser("rmon", "password");
   assertEquals(visitor.getVisitorId(), v1.getVisitorId());
   
  } 

 /**
   * Test case for method searchUser
   * @throws SQLException 
   * @throws ClassNotFoundException 
   */
  @Test
  public void testSearchUser() throws ClassNotFoundException, SQLException {
   /**
    * @TODO: Call searchUser method for valid values of username
    * and password and assert the value of username for the returned type of method
    */  
   visitor=visitorDAO.searchUser("bsmith", "password");
   assertEquals("bsmith",visitor.getUserName());
  }

 /**
   * Test case for method registerVisitorToEvent
   * @throws SQLException 
   * @throws ClassNotFoundException 
   */
  @Test
  public void testRegisterVisitorToEvent() throws ClassNotFoundException, SQLException {
   /**
    * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
    * Pass this visitor object and valid eventid to registerVisitorToEvent method
    * and assert the value
    */  
   int count=0,count1=0;
   Connection c=FERSDataConnection.createConnection();
   PreparedStatement p=c.prepareStatement("select * from eventsessionsignup");
   ResultSet rs=p.executeQuery();
   visitor=visitorDAO.searchUser("ylee", "password");
   while(rs.next()){
    count++;
   }
   try {
    visitorDAO.registerVisitorToEvent(visitor, 1001, 10001);
    rs=p.executeQuery();
   } catch (Exception e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
   while(rs.next()){
    count1++;
   }
   assertEquals(count+1,count1);
   FERSDataConnection.closeConnection();
  } 

 /**
   * Test case for method registeredEvents
   * @throws SQLException 
   * @throws ClassNotFoundException 
   */
  @Test
  public void testRegisteredEvents() throws ClassNotFoundException, SQLException {
   /**
    * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
    * Pass this visitor object and valid eventid to registeredEvents method
    * and assert the value
    */  
   Connection c=FERSDataConnection.createConnection();
   visitor=visitorDAO.searchUser("ylee", "password");
   System.out.println(visitor.getVisitorId());
   PreparedStatement p=c.prepareStatement("select eventid from eventsessionsignup where visitorid=?");
   p.setInt(1, visitor.getVisitorId());
   ResultSet r=p.executeQuery();
   int i=0;
   while(r.next())
   {
    i++;
    System.out.println(i);
   }
   registeredEvents=visitorDAO.registeredEvents(visitor);
   for(Object[] ref:registeredEvents)
   {
    System.out.println("Arrays:"+Arrays.toString(ref));
    
   }
   assertEquals(i,registeredEvents.size());
  }

 /**
   * Test case for method updateVisitor
   * @throws SQLException 
   * @throws ClassNotFoundException 
   */
  @Test
  public void testUpdateVisitor() throws ClassNotFoundException, SQLException {
   /**
    * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
    * Update the value in this visitor object
    * Pass this visitor object to updateVisitor method
    * and assert the value of changed value
    */  
   visitor=visitorDAO.searchUser("Rmon", "password");
   System.out.println("ID: "+visitor.getVisitorId());
   visitor.setFirstName("Debesh");
   visitor.setLastName("Mishra");
   visitor.setUserName("dmishra");
   visitor.setPassword("password");
   visitor.setEmail("new@gmail.com");
   visitor.setPhoneNumber("9899990");
   visitor.setAddress("Hubballi");
   int status=visitorDAO.updateVisitor(visitor);
   assertEquals(true,status>=1); 
  }

 /**
   * Test case for method registeredEvents
   * @throws Exception 
   */
  @Test
  public void testUnregisterEvent() throws Exception {
   /**
    * @TODO: Fetch visitor object by calling searchUser for valid values of username and password
    * Pass this visitor object and valid eventid to unregisterEvent method
    * and assert the value
    */  
   int i=0,j=0,eventId=0,sessionId=0;
   Connection conn=FERSDataConnection.createConnection(); 
   visitor=visitorDAO.searchUser("dmishra", "password");
   System.out.println(visitor.getVisitorId());
   
   PreparedStatement smt1=conn.prepareStatement("select eventid,eventsessionid from eventsessionsignup where visitorid=?");
   smt1.setInt(1, visitor.getVisitorId());
   ResultSet resultSet=smt1.executeQuery();
   while(resultSet.next())
   {
      eventId=resultSet.getInt(1); 
      sessionId=resultSet.getInt(2);
   }
   
   /*PreparedStatement smt3=conn.prepareStatement("select eventsessionid from eventsessionsignup where visitorid=?");
   smt3.setInt(1, visitor.getVisitorId());
   ResultSet resultSet3=smt3.executeQuery();
   while(resultSet3.next())
   {
      sessionId=resultSet3.getInt(1); 
   }*/
   
   
   System.out.println(resultSet);
   PreparedStatement smt2=conn.prepareStatement("select signupid from eventsessionsignup");
   ResultSet resultSet1 = smt2.executeQuery();
   while(resultSet1.next())
   {
    ++i;
    System.out.println("counting  "+i);
   }
   
   visitorDAO.unregisterEvent(visitor,eventId,sessionId);
   
   PreparedStatement smt4=conn.prepareStatement("select signupid from eventsessionsignup");
   ResultSet resultSet2=smt4.executeQuery();
   while(resultSet2.next())
   {
    ++j;
    System.out.println("counting2"+j);
   }
   assertEquals(i,j+1);
   FERSDataConnection.closeConnection();
  }
  
  /**
   * Test case for method change password
   */
  /*@Test
  public void testChangePassword_VisitorNull() {
   *//**
    * @TODO: Call changePassword method by passing visitor object as null
    *//*  
  }*/
  
  /**
   * Test case for method change password
   */
  @Test
  public void testChangePassword_VisitorNull() {
   try {
    visitor = null;
    visitorDAO.changePassword(visitor);
   } catch (SQLException exception) {
    fail("SQL Exception");
   } catch (ClassNotFoundException exception) {
    fail("Class Not Found Exception");
   } catch (Exception exception) {
    fail("NULL Exception");
   }
  }

}
